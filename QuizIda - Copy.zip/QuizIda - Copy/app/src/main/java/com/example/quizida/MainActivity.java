package com.example.quizida;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    static final boolean $assertionsDisabled = false;
    private static final int LOGGED_OUT_USER = 2;
    private static final int REGISTRATION_PAGE = 1;
    private Toast alert;
    private Button btnLogin;
    private EditText etPassword;
    private EditText etUsername;
    private String password;
    private ArrayList<Transaction> transactions;
    private String username;
    private ArrayList<User> users = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        getSupportActionBar().setTitle((CharSequence) "Login Page");
        this.etUsername = findViewById(R.id.etUsername);
        this.etPassword = findViewById(R.id.etPassword);
        this.btnLogin = findViewById(R.id.btnLogin);
        this.transactions = new ArrayList<>();
    }



    public void Login(View view) {

        this.username = this.etUsername.getText().toString();
        this.password = this.etPassword.getText().toString();

        int Logged_User = 0;
        int Status = -1;

        if (this.username.isEmpty() || this.password.isEmpty()) {
            if (this.username.isEmpty()) {
                this.etUsername.setBackgroundResource(R.drawable.errorfield);
                this.etUsername.setError("This field cannot be blank");
            } else {
                this.etUsername.setBackgroundResource(0);
            }
            if (this.password.isEmpty()) {
                this.etPassword.setBackgroundResource(R.drawable.errorfield);
                this.etPassword.setError("This field cannot be blank");
                return;
            }
            this.etPassword.setBackgroundResource(0);
            return;
        }

        this.etUsername.setBackgroundResource(0);
        this.etPassword.setBackgroundResource(0);
        int i = 0;
        while (true) {
            if (this.users.size() > i) {
                if (!this.users.get(i).getUsername().equals(this.username) || !this.users.get(i).getPassword().equals(this.password)) {
                    if (this.users.get(i).getUsername().equals(this.username) && !this.users.get(i).getPassword().equals(this.password)) {
                        Status = 0;
                        break;
                    }
                    i++;
                } else {
                    Status = 1;
                    Logged_User = i;
                    break;
                }
            } else {
                break;
            }
        }

        if (Status == 0) {
            this.etUsername.setBackgroundResource(C0090R.C0092drawable.errorfield);
            this.etPassword.setBackgroundResource(C0090R.C0092drawable.errorfield);
            this.etUsername.setError("Incorrect Username");
            this.etPassword.setError("Incorrect Password");
            Toast.makeText(this, "Username and Password does not match!", 0).show();
        } else if (Status == -1) {
            this.etUsername.setBackgroundResource(R.drawable.errorfield);
            this.etUsername.setError("Username not registered!");
            Toast.makeText(this, "Username not been registered yet!", 0).show();
        } else if (Status == 1) {
            this.etUsername.setBackgroundResource(0);
            this.etPassword.setBackgroundResource(0);
            this.etUsername.setError((CharSequence) null);
            Intent Login = new Intent(this, HomePage.class);
            Login.putExtra("transactions", this.transactions);
            Login.putExtra("loggedUser", this.users.get(Logged_User));
            startActivityForResult(Login, 2);
        }


    }

    public void toRegister(View view) {

        Intent registration = new Intent(this, RegistrationPage.class);
        registration.putParcelableArrayListExtra("Users", this.users);
        startActivityForResult(registration, 1);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if (resultCode != -1) {
                return;
            }
            if (data != null) {
                this.users = data.getParcelableArrayListExtra("Users");
                return;
            }
            throw new AssertionError();
        } else if (requestCode != 2 || resultCode != -1) {
        } else {
            if (data != null) {
                this.transactions = data.getParcelableArrayListExtra("transactions");
                return;
            }
            throw new AssertionError();
        }
    }
}
