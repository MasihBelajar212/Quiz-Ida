package com.example.quizida;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class StoreItemAdapter extends RecyclerView.Adapter<StoreItemAdapter.MyViewHolder> {

   private ArrayList<StoreItem> storeItems;
   private Context context;
   private StorePage storePage2;
   private User user;
   private ArrayList<Transaction> transactions;

    public StoreItemAdapter(Context context2) {
        this.context = context2;

    }

    public void setStoreItems(User user2, ArrayList<Transaction> transactions2, ArrayList<StoreItem> storeItems2)
    {
        this.storeItems = storeItems2;
        this.user = user2;
        this.transactions = transactions2;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(this.context).inflate(R.layout.store_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position)
    {

        holder.productItemName.setText(storeItems.get(position).getProductName());
        if(this.storeItems.get(position).getMaxPlayer() == this.storeItems.get(position).getMinPlayer())
        {
            TextView access = holder.playerMinMax;
            access.setText(this.storeItems.get(position).getMinPlayer() + " Players");
        }
        else
        {
            TextView access2 = holder.playerMinMax;
            access2.setText(this.storeItems.get(position).getMinPlayer() + " - " + this.storeItems.get(position).getMaxPlayer() + " Players");
        }

        holder.productItemPrice.setText(storeItems.get(position).getPrice() + "");

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(StoreItemAdapter.this.context instanceof  StorePage)
                {
                    ((StorePage) StoreItemAdapter.this.context).toItemDetail((StoreItem) StoreItemAdapter.this.storeItems.get(position));
                }
            }
        });

    }

    @Override
    public int getItemCount() {

        return this.storeItems.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
        private TextView playerMinMax;
        private TextView productItemName;
        private TextView productItemPrice;

        public MyViewHolder(@NonNull View itemView)
        {
            super(itemView);

            this.playerMinMax = itemView.findViewById(R.id.playerMinMax);
            this.productItemName = itemView.findViewById(R.id.productItemName);
            this.productItemPrice = itemView.findViewById(R.id.productItemPrice);

        }


    }



}
