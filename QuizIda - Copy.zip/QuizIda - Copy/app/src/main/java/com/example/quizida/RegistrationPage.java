package com.example.quizida;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;

import java.util.ArrayList;
import java.util.Calendar;

public class RegistrationPage extends AppCompatActivity {

    private Intent Registration;
    private DatePickerDialog dialog;
    private String gender;
    private EditText etUsername;
    private EditText etPassword;
    private EditText etConfirmPass;
    private EditText etDOB;
    private EditText etPhone;
    private RadioGroup rdgGender;
    private Calendar date;
    private int day;
    int month;
    private CheckBox chkAggrement;
    private AlertDialog.Builder termAlert;
    private ArrayList<User> users;
    private int year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);

//        getActionBar().setTitle((CharSequence) "Registration Page");
        this.etUsername = findViewById(R.id.etUsername);
        this.etPassword = findViewById(R.id.etPassword);
        this.etConfirmPass = findViewById(R.id.etConfirmPass);
        this.etDOB = findViewById(R.id.etDOB);
        this.etPhone = findViewById(R.id.etPhone);
        this.rdgGender = findViewById(R.id.rdgGender);
        this.chkAggrement = findViewById(R.id.chkAggrement);
        this.termAlert = new AlertDialog.Builder(this);
        Intent intent = getIntent();
        this.Registration = intent;
        this.users = intent.getParcelableArrayListExtra("Users");
        getCheckedGender();

        this.etDOB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar unused = RegistrationPage.this.date = Calendar.getInstance();
                RegistrationPage registrationPage = RegistrationPage.this;
                int unused2 = registrationPage.year = registrationPage.date.get(1);
                RegistrationPage registrationPage2 = RegistrationPage.this;
                int unused3 = registrationPage2.month = registrationPage2.date.get(2);
                RegistrationPage registrationPage3 = RegistrationPage.this;
                int unused4 = registrationPage3.day = registrationPage3.date.get(5);
                DatePickerDialog unused5 = RegistrationPage.this.dialog = new DatePickerDialog(RegistrationPage.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        EditText access$600 = RegistrationPage.this.etDOB;
                        access$600.setText(day + "/" + RegistrationPage.this.setMonth(month) + "/" + year);
                    }
                }, RegistrationPage.this.year, RegistrationPage.this.month, RegistrationPage.this.day);
                RegistrationPage.this.dialog.show();
            }
        });

    }

    private String setMonth(int month2) {

        int month3 = month2 + 1;
        if (month3 == 1) {
            return "Jan";
        }
        if (month3 == 2) {
            return "Feb";
        }
        if (month3 == 3) {
            return "Mar";
        }
        if (month3 == 4) {
            return "Apr";
        }
        if (month3 == 5) {
            return "May";
        }
        if (month3 == 6) {
            return "Jun";
        }
        if (month3 == 7) {
            return "Jul";
        }
        if (month3 == 8) {
            return "Aug";
        }
        if (month3 == 9) {
            return "Sep";
        }
        if (month3 == 10) {
            return "Oct";
        }
        if (month3 == 11) {
            return "Nov";
        }
        if (month3 == 12) {
            return "Dec";
        }
        return null;
    }


    private void getCheckedGender() {

        this.rdgGender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                switch (RegistrationPage.this.rdgGender.getCheckedRadioButtonId())
                {
                    case R.id.rdgGenderMale:
                        String unsused = RegistrationPage.this.gender = "Male";

                    case R.id.rdgGenderFemale:
                        String unsused2 = RegistrationPage.this.gender = "Female";

                    default:
                        String unsused3 = RegistrationPage.this.gender = null;
                        return;
                }
            }
        });

    }

    public void signUp(View view) {
        boolean VALIDITY;
        String username = this.etUsername.getText().toString();
        String password = this.etPassword.getText().toString();
        String confirm = this.etConfirmPass.getText().toString();
        String DOB = this.etDOB.getText().toString();
        String phone = this.etPhone.getText().toString();

        int i =0;

        while (true) {
            if (this.users.size() <= i) {
                VALIDITY = true;
                break;
            } else if (this.users.get(i).getUsername().equals(username)) {
                this.etUsername.setError("Username already existed!");
                VALIDITY = false;
                break;
            } else {
                i++;
            }
        }
        if (validasi() && VALIDITY) {
            this.Registration = new Intent();
            this.users.add(new User(this.users.size(), username, this.gender, DOB, phone, password));
            this.Registration.putParcelableArrayListExtra("Users", this.users);
            setResult(-1, this.Registration);
            finish();
        }

    }

    public void toLogin(View view) {
        finish();
    }

    public boolean validasi() {
        int loginValidity = 0;
        String username = this.etUsername.getText().toString();
        String password = this.etPassword.getText().toString();
        String confirmPass = this.etConfirmPass.getText().toString();
        String DOB = this.etDOB.getText().toString();
        String phone = this.etPhone.getText().toString();
        if (username.isEmpty()) {
            this.etUsername.setBackgroundResource(R.drawable.errorfield);
            this.etUsername.setError("Username cannot be empty!");
            loginValidity = 0 + 1;
        } else if (username.length() < 6 || username.length() > 12) {
            this.etUsername.setBackgroundResource(R.drawable.errorfield);
            this.etUsername.setError("Username must between 6 and 12 characters!");
            loginValidity = 0 + 1;
        } else {
            this.etUsername.setBackgroundResource(0);
        }
        if (password.isEmpty()) {
            this.etPassword.setBackgroundResource(R.drawable.errorfield);
            this.etPassword.setError("Password cannot be empty!");
            loginValidity++;
        } else if (password.length() < 8) {
            this.etPassword.setBackgroundResource(R.drawable.errorfield);
            this.etPassword.setError("Password must be more than 8 characters!");
            loginValidity++;
        } else if (!password.matches("[a-zA-Z0-9]+")) {
            this.etPassword.setBackgroundResource(C0090R.C0092drawable.errorfield);
            this.etPassword.setError("Password must be alphanumeric!");
            loginValidity++;
        } else {
            this.etPassword.setBackgroundResource(0);
        }
        if (confirmPass.isEmpty()) {
            this.etConfirmPass.setBackgroundResource(R.drawable.errorfield);
            this.etConfirmPass.setError("Please input password confirmation!");
            loginValidity++;
        } else if (!confirmPass.equals(password)) {
            this.etConfirmPass.setBackgroundResource(R.drawable.errorfield);
            this.etConfirmPass.setError("Password confirmation does not match!");
            loginValidity++;
        } else {
            this.etConfirmPass.setBackgroundResource(0);
        }
        if (DOB.isEmpty()) {
            this.etDOB.setBackgroundResource(R.drawable.errorfield);
            this.etDOB.setError("Date of birth cannot be empty!");
            loginValidity++;
        } else {
            this.etDOB.setBackgroundResource(0);
            this.etDOB.setError((CharSequence) null);
        }
        if (phone.isEmpty()) {
            this.etPhone.setBackgroundResource(R.drawable.errorfield);
            this.etPhone.setError("Phone number cannot be empty!");
            loginValidity++;
        } else if (phone.length() < 10 || phone.length() > 12) {
            this.etPhone.setBackgroundResource(R.drawable.errorfield);
            this.etPhone.setError("Phone number must between 10 and 12 digits!");
            loginValidity++;
        } else if (phone.matches("/d")) {
            this.etPhone.setBackgroundResource(C0090R.C0092drawable.errorfield);
            this.etPhone.setError("Phone must be digit only!");
            loginValidity++;
        } else {
            this.etPhone.setBackgroundResource(0);
        }
        if (this.rdgGender.getCheckedRadioButtonId() == -1) {
            this.rdgGender.setBackgroundResource(R.drawable.errorfield);
            loginValidity++;
        } else {
            this.rdgGender.setBackgroundResource(0);
        }
        if (!this.chkAggrement.isChecked()) {
            new alertPopUp("Term of Service").show(getSupportFragmentManager(), "ToS Agreement");
            loginValidity++;
        }
        if (loginValidity > 0) {
            return false;
        }
        return true;
    }

}