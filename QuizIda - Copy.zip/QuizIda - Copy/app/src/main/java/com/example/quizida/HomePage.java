package com.example.quizida;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class HomePage extends AppCompatActivity {

    private static final int PROFILE_PAGE = 2;
    private static final int STORE_PAGE = 1;
    private Intent Login;
    private TransactionAdapter adapter;
    private TextView recycleViewAlert;
    private RecyclerView rv_transaction;
    private ArrayList<Transaction> transactions;
    private User user;
    private TextView tv_usergreet;
    private TextView tv_wallet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

//        getSupportActionBar().setTitle((CharSequence) "Home Page");
        this.rv_transaction = findViewById(R.id.rv_transaction);
        this.tv_usergreet = findViewById(R.id.tv_usergreet);
        this.tv_wallet = findViewById(R.id.tv_wallet);
        this.recycleViewAlert = findViewById(R.id.recycleViewAlert);
        Intent intent = getIntent();
        this.Login = intent;
        this.user = (User) intent.getParcelableExtra("loggedUser");
        this.transactions = this.Login.getParcelableArrayListExtra("transactions");
        TextView textView = this.tv_usergreet;
        textView.setText("Welcome back, " + this.user.getUsername() + "!");
        TextView textView2 = this.tv_wallet;
        textView2.setText("Rp." + this.user.getWallet());
        TransactionAdapter transactionAdapter = new TransactionAdapter(this);
        this.adapter = transactionAdapter;
        transactionAdapter.setTransactions(this.user.getId(), this.transactions);
        this.rv_transaction.setAdapter(this.adapter);
        this.rv_transaction.setLayoutManager(new LinearLayoutManager(this,1,false));

        if(this.adapter.getItemCount() == 0)
        {
            showEmptyAlert();
        }

    }

    private void showEmptyAlert()
    {
        this.recycleViewAlert.setText(R.string.No_Transaction_Alert);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_page_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.homeMenu:
                Toast.makeText(this, "Ke home page", 0).show();
                return true;

            case R.id.logOutMenu:
                Intent intent = new Intent();
                intent.putParcelableArrayListExtra("transactions", this.transactions);
                setResult(-1, intent);
                finish();
                return true;

            case R.id.profileMenu:
                Intent intent2 = new Intent(this, ProfilePage.class);
                intent2.putExtra("user", this.user);
                startActivityForResult(intent2, 2);
                return true;

            case R.id.storeMenu:
                Intent intent3 = new Intent(this, StorePage.class);
                intent3.putParcelableArrayListExtra("transactions", this.transactions);
                intent3.putExtra("user", this.user);
                startActivityForResult(intent3, 1);
                return true;
            default:

                return super.onOptionsItemSelected(item);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == -1) {
            this.adapter = new TransactionAdapter(this);
            this.user = (User) data.getParcelableExtra("user");
            this.transactions = data.getParcelableArrayListExtra("transactions");
            this.adapter.setTransactions(this.user.getId(), this.transactions);
            this.rv_transaction.setAdapter(this.adapter);
            if (this.adapter.getItemCount() > 0) {
                this.recycleViewAlert.setText((CharSequence) null);
            }
            TextView textView = this.tv_wallet;
            textView.setText("Rp." + this.user.getWallet());
        }
        if (requestCode == 2 && resultCode == -1) {
            this.user = (User) data.getParcelableExtra("user");
            TextView textView2 = this.tv_wallet;
            textView2.setText("Rp." + this.user.getWallet());
        }

    }

}